import React, { useState } from 'react';
import { AuthForm } from './components/AuthForm';
import { TimetableGenerator } from './components/TimetableGenerator';
import { TimetableList } from './components/TimetableList';
import { useAuthStore } from './store/authStore';
import { Calendar, LogOut, Plus, List } from 'lucide-react';

function App() {
  const { user, signOut } = useAuthStore();
  const [view, setView] = useState('create'); // 'create' or 'list'

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center">
              <Calendar className="mr-2" size={32} />
              School Timetable Generator
            </h1>
            <p className="text-gray-600">Create and manage your school timetables efficiently</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <AuthForm type="login" />
            <AuthForm type="register" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-blue-500" />
              <span className="ml-2 text-xl font-semibold">Timetable Generator</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex space-x-2">
                <button
                  onClick={() => setView('create')}
                  className={`inline-flex items-center px-4 py-2 rounded-md text-sm font-medium ${
                    view === 'create'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  <Plus size={16} className="mr-2" />
                  Create Timetable
                </button>
                <button
                  onClick={() => setView('list')}
                  className={`inline-flex items-center px-4 py-2 rounded-md text-sm font-medium ${
                    view === 'list'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  <List size={16} className="mr-2" />
                  View Timetables
                </button>
              </div>
              <span className="text-gray-600">Welcome, {user.name}</span>
              <button
                onClick={signOut}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
              >
                <LogOut className="mr-2" size={16} />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {view === 'create' ? <TimetableGenerator /> : <TimetableList />}
      </main>
    </div>
  );
}

export default App;