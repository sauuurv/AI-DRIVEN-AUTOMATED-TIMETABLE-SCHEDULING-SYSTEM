import { create } from 'zustand';

export const useAuthStore = create((set) => ({
  user: JSON.parse(localStorage.getItem('user')),
  setUser: (user) => {
    localStorage.setItem('user', JSON.stringify(user));
    set({ user });
  },
  signOut: () => {
    localStorage.removeItem('user');
    localStorage.removeItem('timetable');
    set({ user: null });
  },
}));